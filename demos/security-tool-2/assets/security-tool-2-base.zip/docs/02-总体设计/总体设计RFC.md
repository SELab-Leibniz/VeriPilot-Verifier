# SecurityTool 总体设计 RFC

> 状态：Active
> 日期：2026-04-08
> 适用范围：SecurityTool 商业项目当前交付版本与后续版本规划
> 配套文档：
> - `docs/02-总体设计/PRD.md`
> - `docs/03-模块设计/安全总览组件设计说明.md`
> - `docs/03-模块设计/防火墙管理组件设计说明.md`
> - `docs/03-模块设计/外设管理组件设计说明.md`
> - `docs/03-模块设计/权限管理组件设计说明.md`
> - `docs/03-模块设计/身份鉴别组件设计说明.md`
> - `docs/03-模块设计/日志管理组件设计说明.md`
> - `docs/03-模块设计/工具设置组件设计说明.md`
> - `docs/03-模块设计/帮助与反馈组件设计说明.md`

## 1. 文档定位

本文是商业项目版本的总体设计总 RFC，直接用于以下场景：

- 给产品、研发、测试对齐交付范围
- 给管理层判断当前版本“卖什么、交什么、不交什么”
- 给开发团队明确每个模块的目标能力、页面结构、关键动作链路和验收标准

本文不讲空泛背景，不讨论历史过程，直接定义当前版本的业务交付面。

## 2. 产品交付定义

### 2.1 产品定位

SecurityTool 是面向 HarmonyOS 2in1 设备的企业安全管理工具，交付对象是企业客户、行业客户和项目型集成客户。它不是面向个人消费者的系统设置页集合，而是一个可交付、可验收、可演示的本地安全管理中心。

### 2.2 当前版本卖点

当前版本对外可讲的核心卖点有七个：

1. 统一安全入口
2. 防火墙策略控制
3. 外设接口与设备管控
4. 应用权限与运行策略入口
5. 身份与账户策略配置
6. 安全日志采集与审计导出
7. 工具自身的启动认证保护

### 2.3 目标客户的直接价值

| 客户角色 | 购买/验收关注点 | 当前版本提供的价值 |
|---|---|---|
| 企业 IT 管理员 | 能不能快速配置安全策略 | 提供统一入口和分模块控制页面 |
| 安全管理员 | 能不能看状态、留痕、复核 | 提供首页摘要、日志管理、策略回显 |
| 项目交付方 | 能不能在设备上落地演示和验收 | 提供可构建、可签名、可安装、可实操的完整链路 |

## 3. 当前版本总范围

### 3.1 包含的模块

| 模块 | 路由 | 当前版本是否交付 |
|---|---|---|
| 安全总览 | `dashboard` | 是 |
| 防火墙管理 | `firewall` / `firewall-rules` | 是 |
| 日志管理 | `log-manage` | 是 |
| 外设管理 | `peripheral-manage` | 是 |
| 权限管理 | `permission-manage` | 首版只读骨架 |
| 身份鉴别 | `identity` | 是 |
| 工具设置 | `tool-settings` | 是 |
| 帮助与反馈 | `help-feedback` | 辅助页，不是核心卖点 |

### 3.2 不包含的范围

当前版本明确不交付以下能力：

- 服务端集中管控后台
- 多设备统一编排
- 云端策略同步
- 杀毒、漏洞扫描、补丁管理
- 复杂报表平台

## 4. 总体页面与导航结构

### 4.1 统一入口

- 入口页：`pages/MainPage`
- 页面容器：侧边栏 + 顶部操作区 + 主内容区
- 统一路由常量：`RouteIds`

### 4.2 页面导航逻辑

```text
MainPage
  -> 安全总览
  -> 防火墙管理
  -> 日志管理
  -> 外设管理
  -> 权限管理
  -> 身份鉴别
  -> 工具设置
```

### 4.3 商业演示顺序建议

对外演示建议按以下顺序：

1. 先打开安全总览，讲“统一入口 + 当前状态”
2. 进入防火墙，讲“网络控制能力”
3. 进入外设管理，讲“接口和设备安全”
4. 进入权限管理，讲“应用级管控入口”
5. 进入身份鉴别，讲“账户策略”
6. 进入日志管理，讲“审计留痕”
7. 进入工具设置，讲“工具本身受保护”

## 5. 总体技术收口

### 5.1 分层要求

统一分层如下：

```text
Page -> ViewModel -> Service -> Repository/Store/Provider -> HarmonyOS API
```

### 5.2 每层要做什么

#### Page

- 负责展示
- 负责交互事件转发
- 负责弹窗、局部 loading、局部 hover 这类 UI 行为

#### ViewModel

- 负责业务页面状态
- 负责初始化、刷新、保存、提交流程
- 负责将 service 结果转成页面状态

#### Service

- 负责领域动作编排
- 负责把多个底层能力收敛成一个业务动作

#### Repository / Store / Provider

- Repository：系统能力或数据读写
- Store：本地偏好或持久化状态
- Provider：用户、环境、上下文等来源

### 5.3 明确禁止

- 页面直接串多个 service 拼业务流程
- `MainPage` 直接承担模块业务逻辑
- 子组件自行维护完整业务状态副本
- 为了修局部 bug 在页面层补镜像态

### 5.4 架构落地视图

当前代码按“应用入口 + 页面路由 + 模块 MVVM + 领域服务 + 平台能力适配”落地：

```text
EntryAbility
  -> ApplicationRuntimeManager
  -> MainPage(RouteIds)
  -> Module Page
  -> Module ViewModel
  -> Module Service / Domain Use Case
  -> Repository / Provider / Adapter
  -> HarmonyOS API / MDM API / Preferences / RDB
```

各入口职责：

| 架构节点 | 当前落点 | 职责 |
|---|---|---|
| 应用启动 | `entry/src/main/ets/entryability/EntryAbility.ets` | 初始化主题、执行启动认证、加载 `pages/MainPage`、处理生命周期事件 |
| 运行时服务 | `entry/src/main/ets/runtime/ApplicationRuntimeManager.ets` | 管理跨页面运行态，如日志采集、外设连接记录采集、共享 ViewModel |
| 路由壳层 | `entry/src/main/ets/pages/MainPage.ets` | 持有当前路由，装配侧边栏、顶部菜单和模块页面，不承载模块内部业务 |
| 页面层 | `entry/src/main/ets/views/**` | 展示、交互转发、弹窗、局部 UI 状态 |
| 状态层 | `entry/src/main/ets/viewmodels/**` | 初始化、刷新、保存、提交、结果映射和页面状态收口 |
| 领域层 | `entry/src/main/ets/services/**` | 系统能力编排、策略下发、采集、导出、认证等业务动作 |
| 持久化层 | `entry/src/main/ets/storage/**`、模块 Repository | Preferences / RDB 访问、表结构、配置读写、查询和裁剪 |
| 公共能力 | `entry/src/main/ets/components/**`、`utils/**`、`constants/**`、`theme/**` | UI 复用、日志、弹窗、导出文案、路径处理、主题和文案常量 |

跨模块依赖边界：

- 安全总览可以读取管理员、防火墙、日志和外设摘要，但不直接改写其它模块状态。
- 工具设置负责工具自身启动认证；防火墙敏感操作认证直接复用身份认证能力，不消费工具设置配置。
- 日志管理作为审计留痕模块，运行时采集由 `ApplicationRuntimeManager` 拉起，页面只展示和操作日志查询/导出。
- 外设运行时采集由 `ApplicationRuntimeManager` 拉起，外设页面不直接启动后台采集管线。
- 权限管理首版只提供路由、只读骨架和状态模型，不新增签名权限，不触发应用安装、卸载、运行、网络或保活写操作。
- 帮助与反馈是静态辅助页，不进入核心安全闭环，不引入 Service、Repository 或权限依赖。

#### 5.4.1 文档与实现对齐矩阵

| 模块 | 路由 | 页面 / 状态落点 | 领域 / 存储落点 | 测试落点 |
|---|---|---|---|---|
| 安全总览 | `dashboard` | `DashboardPage.ets`、`DashboardViewModel.ets` | 无独立 Service；只读管理员、防火墙、日志、外设摘要 | `entry/src/test/dashboard/*`、`entry/src/ohosTest/ets/test/simple/RouteAction.test.ets`、`scripts/e2e/cases/dashboard/*` |
| 防火墙管理 | `firewall`、`firewall-rules` | `FirewallPage.ets`、`FirewallRulesPage.ets`、`FirewallOverviewViewModel.ets`、`FirewallRulesViewModel.ets` | `services/firewall/**`、Preferences 本地意图与系统防火墙 Provider | `entry/src/test/firewall/*`、`entry/src/ohosTest/ets/test/firewall/subroute-state.test.ets`、`entry/src/ohosTest/ets/test/simple/RouteAction.test.ets`、`scripts/e2e/cases/firewall/*` |
| 日志管理 | `log-manage` | `LogManagePage.ets`、`LogManageViewModel.ets`、`LogStorageSettingsViewModel.ets` | `services/log-manage/**`、`storage/rdb/**` | `entry/src/test/log-manage/*`、`entry/src/ohosTest/ets/test/simple/RouteAction.test.ets`、`scripts/e2e/cases/logs/*` |
| 外设管理 | `peripheral-manage` | `PeripheralPage.ets`、`PeripheralViewModel.ets`、`InterfaceControlViewModel.ets`、`PeripheralRecordViewModel.ets`、`PeripheralPolicyViewModel.ets` | `services/peripheral/**`、运行时 Producer / Pipeline、RDB trace、设备策略 Preferences | `entry/src/test/peripheral/*`、`entry/src/test/viewmodels/Peripheral*.test.ets`、`entry/src/ohosTest/ets/test/peripheral/connection-record-contract.test.ets`、`entry/src/ohosTest/ets/test/simple/RouteAction.test.ets`、`scripts/e2e/cases/peripheral/*` |
| 权限管理 | `permission-manage` | `PermissionPage.ets`、`PermissionViewModel.ets` | `PermissionService.ets` 首版只读初始态；后续真实能力再拆 Repository / Provider | `entry/src/test/permission-manage/*`、`entry/src/ohosTest/ets/test/simple/RouteAction.test.ets` |
| 身份鉴别 | `identity` | `IdentityPage.ets`、`IdentitySettingsViewModel.ets` | `IdentityService.ets`、`IdentityPasswordPolicyMapper.ets`、`AuthService.ets` | `entry/src/test/identity/*`、`entry/src/test/auth/*`、`entry/src/ohosTest/ets/test/simple/RouteAction.test.ets`、`scripts/e2e/cases/identity/*` |
| 工具设置 | `tool-settings` | `ToolSettingsPage.ets`、`ToolSettingsViewModel.ets` | `ToolSettingsRepository.ets`、`SystemSettingsService.ets`、`EntryAbility.ets` 启动消费链路 | `entry/src/test/tool-settings/*`、`entry/src/test/entryability/*`、`entry/src/ohosTest/ets/test/simple/RouteAction.test.ets`、`scripts/e2e/cases/tool_settings/*` |
| 帮助与反馈 | `help-feedback` | `HelpFeedbackPage.ets` | 无 Service / Repository / Storage；静态内容来自 `HelpFeedbackStrings.ets` | `entry/src/test/help/*`、`entry/src/ohosTest/ets/test/simple/RouteAction.test.ets`、`scripts/e2e/cases/navigation/help_feedback*.json` |

### 5.5 实施步骤

新增或调整业务模块时，按以下顺序实施：

1. 明确产品范围：先更新 `docs/02-总体设计/PRD.md` 和本文档中的模块范围、交付能力、非目标。
2. 更新模块设计：在 `docs/03-模块设计/` 中补齐入口路由、状态模型、数据流、ViewModel / Service / Repository 职责、系统能力、权限、异常兜底和测试边界。
3. 更新配置契约：如涉及包名、权限或签名能力，同步检查 `AppScope/app.json5`、`entry/src/main/module.json5`、`hapsigner/UnsgnedDebugProfileTemplate.json`。
4. 实施代码：按 Page -> ViewModel -> Service -> Repository/Provider/Adapter 的方向落地；页面只转发交互，业务状态在 ViewModel 收口。
5. 补齐测试：低风险纯函数补 UT；状态流、仓储和服务补本地 UT；页面路由和设备能力补 ohosTest；端到端闭环补 `scripts/e2e/cases`。
6. 构建签名：按 `AGENTS.md` 的 hvigor 查找和签名流程构建 unsigned HAP、同步到 `hapsigner/`、签名生成 `signApp.hap`。
7. 设备验收：安装主包和测试包，激活企业管理员，执行默认设备冒烟和模块相关可选场景。
8. 回写文档：如验证中发现行为边界、失败策略或验收口径变化，先回写模块设计文档，再提交代码。

#### 5.5.1 RFC 分层与实现走样检查

当前检查结论：总体 RFC 的主分层与现有实现基本一致，未发现页面绕过 ViewModel 直接下发系统能力、`MainPage` 承担模块核心业务、或模块专项设计散落到独立过程目录的走样。需要记录的实现差异是：共享 ViewModel 并非全部由 `ApplicationRuntimeManager` 持有，防火墙总览、规则页和权限管理首版 ViewModel 目前由 `MainPage` 持有，用于保持路由状态；该差异仍在“路由壳层装配页面、不承载模块业务”的边界内。

| RFC 分层 | RFC 预期职责 | 当前实现落点 | 走样检查结论 |
|---|---|---|---|
| 应用启动层 | 负责主题初始化、启动认证、加载 `pages/MainPage`、拉起应用级运行时 | `entry/src/main/ets/entryability/EntryAbility.ets`、`ToolSettingsRepository.ets`、`AuthService.ets`、`ApplicationRuntimeManager.ets` | 一致。启动认证由工具设置配置驱动，认证失败/不可用分支有降级或终止处理。 |
| 运行时服务层 | 管理跨页面运行态和后台采集，不让页面直接启动采集管线 | `entry/src/main/ets/runtime/ApplicationRuntimeManager.ets` 管理日志采集、外设运行时、共享身份/日志/外设/工具设置 ViewModel | 基本一致。防火墙和权限管理 ViewModel 由 `MainPage` 持有是路由状态需要，不涉及系统能力直接下发。 |
| 路由壳层 | 持有当前路由、装配侧边栏/顶部菜单/模块页面，不承载模块业务 | `entry/src/main/ets/pages/MainPage.ets`、`RouteStateUtils.ets`、`RouteIds.ets` | 一致。`MainPage` 只做路由、主题、弹窗入口和 ViewModel 注入；防火墙子路由恢复通过 `lastFirewallRoute` 收口。 |
| 页面层 | 负责展示、交互转发、弹窗和局部 UI 状态 | `entry/src/main/ets/views/**`、`entry/src/main/ets/components/**` | 一致。页面消费 ViewModel state 和回调；`FirewallRulesPage` 引入 `netFirewall` 仅用于规则类型/枚举展示和弹窗参数，新增/编辑/删除仍经 `FirewallRulesViewModel`，不是页面直接下发系统能力。 |
| 状态层 | 收口初始化、刷新、保存、提交、结果映射和页面状态 | `entry/src/main/ets/viewmodels/**` | 一致。业务状态集中在各模块 ViewModel，页面没有成为持久业务真相源。 |
| 领域服务层 | 编排系统能力、认证、策略下发、采集、导出等业务动作 | `entry/src/main/ets/services/**`、`entry/src/main/ets/services/admin/**` | 一致。防火墙、身份、日志、外设、工具设置均有明确 Service / task / adapter 边界。 |
| 仓储/适配层 | 负责 Preferences、RDB、系统 Provider / Adapter，不把存储细节泄漏给页面 | `entry/src/main/ets/storage/**`、`services/**/repository/**`、`services/**/providers/**`、`UserAuthAdapter.ets` | 一致。仓储分布在模块 service 目录和公共 storage 目录，没有单独根 `repositories` 目录，但职责符合 RFC。 |
| 测试层 | 用 UT / ohosTest / E2E 分别覆盖纯逻辑、页面/设备能力和端到端链路 | `entry/src/test/**`、`entry/src/ohosTest/ets/test/**`、`scripts/e2e/cases/**` | 一致。各模块已有对应测试入口，具体覆盖边界以模块设计 4.1 为准。 |
| 文档层 | PRD 管范围，RFC 管分层和拆分，模块设计管状态/职责/异常/测试 | `docs/02-总体设计/**`、`docs/03-模块设计/**` | 一致。本次移除简化流程摘要，避免把低层流程描述误当 RFC 设计契约。 |

#### 5.5.2 拆分步骤与不走路径

| 拆分阶段 | 必须做 | 明确不走 |
|---|---|---|
| PRD | 更新产品范围、模块状态、验收目标和 PRD/RFC/实现对齐矩阵 | 不在 PRD 里写代码级细节或临时过程记录 |
| 总体 RFC | 更新架构边界、跨模块依赖、分层实现对照、拆分步骤、权限/运行时约束 | 不把单模块内部实现细节散落到独立过程目录 |
| 模块设计 | 更新状态模型、数据模型、组件职责、测试覆盖和验收口径 | 不只在文件末尾追加一句说明，不保留与代码冲突的旧 RFC |
| 代码实现 | 按 Page -> ViewModel -> Service -> Repository/Provider/Adapter 分层落地 | 不让页面直连系统 API、RDB、Preferences 或多个 Service 拼业务；页面可消费平台类型/枚举作为展示数据契约，但不能直接执行系统读写 |
| 测试验证 | 按 UT / ohosTest / E2E 分层补证据，权限变更要补签名验证 | 不用只跑单个页面截图替代状态流和失败分支验证 |
| 提交前自检 | 检查路径、权限、路由、测试用例、UTF-8 和变更日志一致 | 不提交乱码、无引用过程文档或未解释的无用文件 |

### 5.6 验收闭环

每个模块最少需要具备以下验收证据：

| 验收维度 | 文档落点 | 代码/测试落点 |
|---|---|---|
| 入口可达 | PRD、总体 RFC、模块设计第 1/3 章 | `RouteIds`、`MainPage`、ohosTest 路由用例 |
| 状态可信 | 模块设计第 2 章 | ViewModel UT、Repository/Service UT |
| 系统能力边界 | 模块设计第 3.2/4 章 | Service/Adapter 实现、权限声明、签名模板 |
| 异常兜底 | 模块设计第 4 章 | 失败分支 UT、页面提示、日志输出 |
| 设备可验收 | README、AGENTS、测试文档 | HAP 构建、签名、安装、`aa test`、E2E case |
| 文档一致性 | README 关键文档索引、模块设计变更日志 | Markdown 链接检查、UTF-8 回读、权限/路由/测试数量核对 |

## 6. 模块级交付说明

## 6.1 安全总览

### 6.1.1 模块定位

安全总览是首页，不承担具体策略编辑，承担三件事：

- 当前安全状态一眼可见
- 模块入口一键可达
- 首页作为客户演示起点

### 6.1.2 当前版本具体功能

当前版本交付两类内容：

1. 模块摘要卡
2. 快捷入口卡

摘要卡当前聚焦四项：

- 管理员状态
- 防火墙状态
- 日志状态
- 外设状态

快捷入口当前提供：

- 防火墙
- 日志管理
- 外设管理
- 权限管理
- 身份鉴别
- 工具设置

### 6.1.3 用户在本模块具体做什么

- 打开应用后先看当前关键状态
- 判断管理员是否已激活
- 判断防火墙是否开启
- 看日志是否在运行、外设是否有活动
- 从快捷入口跳到目标模块

### 6.1.4 成功标准

- 首页进入后核心状态可读
- 首页不是空壳，需要能反映真实摘要
- 从首页进入其它模块路径短、无歧义

### 6.1.5 当前不做

- 不在首页直接编辑复杂策略
- 不把首页做成大看板系统
- 不做跨模块配置面板

## 6.2 防火墙管理

### 6.2.1 模块定位

防火墙管理是当前版本最强的网络安全能力模块，也是商业演示中的核心能力之一。

### 6.2.2 当前版本具体功能

交付四类能力：

1. 主防火墙总开关
2. 预设模式切换
3. 自定义规则维护
4. 按用户 ID 的模式下发

具体到用户可见动作：

- 打开/关闭主防火墙
- 在公共网络、私有网络、自定义模式之间切换
- 新增、编辑、删除自定义规则
- 保存自定义规则模板
- 对指定用户下发白名单模式或黑名单模式

### 6.2.3 页面结构

- 防火墙总览页：负责总开关、主模式、入口跳转
- 防火墙规则页：负责自定义规则和用户模式下发

### 6.2.4 关键动作链路

#### 动作 A：主开关切换

用户点击开关
-> 触发 PIN 认证
-> 认证成功后修改系统防火墙启停状态
-> 页面回显结果

#### 动作 B：主模式切换

用户选择 `public/private/custom`
-> 读取对应规则模板
-> 整套替换默认用户策略
-> 页面回显当前模式

#### 动作 C：自定义规则保存

用户编辑规则
-> 做冲突检查
-> 本地持久化模板
-> 对默认用户重新应用自定义规则
-> 如有绑定用户则同步重下发

#### 动作 D：用户模式下发

用户选择目标 `userId`
-> 选择 allowlist/denylist
-> PIN 认证
-> 应用用户级规则
-> 页面给出成功/失败结论

### 6.2.5 商业价值

- 能直接体现“企业网络控制能力”
- 能做可视化演示
- 能支撑客户对“受保护安全操作”的预期

### 6.2.6 成功标准

- 主开关能正确回显
- 三种主模式切换有稳定结果
- 自定义规则可保存、可恢复、可再次编辑
- 用户下发流程可完成，且有认证保护

### 6.2.7 当前不做

- 不做复杂企业级策略编排平台
- 不做远程统一批量下发
- 不做多租户防火墙管理控制台

## 6.3 日志管理

### 6.3.1 模块定位

日志管理是商业交付里的“可审计、可留痕、可导出”模块，它决定产品不是单纯的控制台，而是具备审计闭环。

### 6.3.2 当前版本具体功能

当前交付五类能力：

1. 运行时采集状态展示
2. 日志列表查询
3. 条件筛选
4. 详情查看
5. 导出

### 6.3.3 用户在本模块具体做什么

- 进入日志页确认采集是否在运行
- 按事件类型、结果和关键词筛选日志
- 浏览分页列表
- 打开单条详情查看完整信息
- 导出日志留档

### 6.3.4 页面结构

- 日志列表区
- 统计摘要区
- 筛选区
- 详情弹窗
- 存储设置子区域

### 6.3.5 关键动作链路

#### 动作 A：列表初始化

页面进入
-> ViewModel 初始化
-> 获取日志快照
-> 构造统计、列表、分页、筛选提示
-> 页面直接渲染

#### 动作 B：筛选

用户调整筛选条件
-> ViewModel 重新构造查询
-> 重置分页
-> 刷新列表和统计展示

#### 动作 C：打开详情

用户点击日志项
-> 固化点击当下的稳定快照
-> 打开详情弹窗
-> 详情不受后续列表刷新污染

#### 动作 D：导出

用户点击导出
-> 调用导出服务
-> 返回成功/失败结果
-> 页面给出明确提示

### 6.3.6 商业价值

- 客户可以看到“策略执行后的审计结果”
- 可以形成验收留痕材料
- 可以支撑问题复盘和项目交付说明

### 6.3.7 成功标准

- 列表、筛选、分页状态一致
- 详情不乱跳
- 导出有结果、有反馈
- 高频刷新时页面不明显失稳

### 6.3.8 当前不做

- 不做企业级 SIEM 平台
- 不做复杂报表大屏
- 不做跨设备聚合查询

## 6.4 外设管理

### 6.4.1 模块定位

外设管理是终端安全控制模块，面向客户最直接可感知，因为它对应 USB、蓝牙等真实硬件能力。

### 6.4.2 当前版本具体功能

当前交付三大子域：

1. 接口管控
2. 设备连接记录
3. 单设备策略

#### 接口管控当前支持

- USB
- 蓝牙
- Wi-Fi
- HDC
- 网络共享
- 打印机
- 麦克风
- 摄像头

#### 连接记录当前支持

- USB 插入/拔出记录
- 蓝牙 ACL 连接/断开记录
- 时间、设备名称、设备类型、设备标识、命中策略结果

#### 单设备策略当前支持

- 对具体设备设置 allow
- 对具体设备设置 deny
- 清空策略

### 6.4.3 用户在本模块具体做什么

- 打开某类接口总开关
- 关闭某类接口总开关
- 查看最近接入过哪些设备
- 点开某条连接记录看详情
- 对某个具体设备设置允许或禁止
- 清空连接记录
- 清空设备策略

### 6.4.4 页面结构

- 接口控制区
- 连接记录区
- 单设备策略区
- 详情弹窗区

### 6.4.5 关键动作链路

#### 动作 A：接口管控

用户切换接口状态
-> ViewModel 调用外设 service
-> 系统策略生效
-> 页面回显当前状态

#### 动作 B：连接记录采集

运行时收到 USB/蓝牙公共事件
-> 写入 trace 仓库
-> 页面刷新列表摘要
-> 可查看详情

#### 动作 C：单设备策略设置

用户从候选设备中选择设备
-> 设置 allow/deny
-> 写入 device policy 仓库
-> 页面刷新策略状态

### 6.4.6 商业价值

- 能非常直观展示“设备侧管控”
- 对政企、信创、涉密场景更容易被客户理解
- 结合连接记录后，既能控制，也能回看

### 6.4.7 成功标准

- 接口控制有结果
- 连接记录能采到、能看、能清
- 单设备策略能保存、能恢复
- 页面三块内容不会互相混淆

### 6.4.8 当前不做

- 不做完整外设资产管理平台
- 不做所有蓝牙协议层的深度控制
- 不做复杂审批流

## 6.5 权限管理

### 6.5.1 模块定位

权限管理模块是应用级安全管控入口，用于把非系统预装应用的安装、运行、目录权限、网络和保活策略收敛到同一账号上下文内。当前首版只交付入口和只读骨架，不开放系统写操作。

### 6.5.2 当前版本具体功能

当前交付三类内容：

1. 侧边栏和首页快捷入口
2. 策略摘要只读骨架
3. 应用管控对象空态

具体动作包括：

- 从侧边栏进入权限管理页
- 从安全总览快捷入口进入权限管理页
- 查看首版范围说明
- 查看后续应用清单接入空态

### 6.5.3 用户在本模块具体做什么

- 打开权限管理入口
- 确认该模块后续承载应用级管控能力
- 在首版看到清晰的只读范围和管理员依赖说明

### 6.5.4 关键动作链路

页面进入
-> 初始化 `PermissionViewModel`
-> `PermissionService` 返回首版只读初始态
-> 页面展示策略摘要、首版范围和应用清单空态
-> 不触发任何安装、卸载、运行、网络或保活写操作

### 6.5.5 商业价值

- 为应用级安全治理留出清晰入口
- 让安全中心能力从设备、网络、账户扩展到应用维度
- 便于后续按阶段接入真实企业管理 API

### 6.5.6 成功标准

- 权限管理在侧边栏和首页快捷入口中可达
- 页面可渲染且无白屏
- 首版不新增签名权限，不触发 MDM 写操作

### 6.5.7 当前不做

- 不读取真实应用清单
- 不设置安装、卸载或运行策略
- 不设置 6D 权限、网络策略、保活或自启动策略

## 6.6 身份鉴别

### 6.6.1 模块定位

身份鉴别模块是账户安全策略页面，用于向客户展示本工具不仅能控网络和外设，也能控账户安全基线。

### 6.6.2 当前版本具体功能

当前交付两类配置：

1. 口令复杂度策略
2. 密码有效期策略

具体动作包括：

- 配置最低长度
- 配置复杂度要求
- 配置密码有效期
- 配置自定义有效期
- 感知管理员是否激活

### 6.6.3 用户在本模块具体做什么

- 打开当前密码策略页面
- 查看系统当前策略
- 修改策略输入值
- 保存策略
- 在未激活管理员时看到受限提示

### 6.6.4 关键动作链路

页面进入
-> 读取当前系统策略和管理员状态
-> 构造页面编辑态
-> 用户修改
-> 保存前做合法性检查和规则构造
-> 调用系统策略写入
-> 页面回显成功/失败结果

### 6.6.5 商业价值

- 体现“安全基线配置能力”
- 补足终端侧账户安全治理场景
- 对项目交付和方案完整性有帮助

### 6.6.6 成功标准

- 当前策略可读取
- 修改后可保存
- 保存失败时不丢编辑内容
- 管理员未激活时提示明确

### 6.6.7 当前不做

- 不做统一身份认证平台
- 不做企业账号体系
- 不做生物特征策略全量编排

## 6.7 工具设置

### 6.7.1 模块定位

工具设置不是“杂项设置页”，而是本工具自身的安全设置页，用于保证应用本身受保护。

### 6.7.2 当前版本具体功能

当前交付两类能力：

1. 启动认证设置
2. 系统密码入口跳转

具体动作包括：

- 启用或关闭启动身份校验
- 选择认证方式
- 检查认证方式当前是否可用
- 跳转系统密码设置页

### 6.7.3 用户在本模块具体做什么

- 进入工具设置页
- 决定启动时是否需要校验
- 选择 PIN 或指纹
- 保存配置
- 需要时进入系统密码页修改密码

### 6.7.4 关键动作链路

#### 动作 A：保存启动认证设置

页面进入
-> 读取偏好配置
-> 用户调整开关和认证方式
-> 保存前检查认证方式是否可用
-> 写回 preferences
-> 页面显示结果

#### 动作 B：打开系统密码页

用户点击修改密码
-> 调用 SystemSettingsService
-> 拉起系统设置页面
-> 返回成功/失败

### 6.7.5 商业价值

- 让客户看到“工具自身也受保护”
- 与防火墙、外设、身份策略形成闭环，而不是裸奔工具

### 6.7.6 成功标准

- 配置可保存、可恢复
- 不可用认证方式不会被错误保存
- 系统密码入口可达

### 6.7.7 当前不做

- 不把所有系统设置项塞进来
- 不承载其它模块的业务认证逻辑

## 6.8 帮助与反馈

### 6.8.1 模块定位

帮助与反馈是辅助信息页，不属于核心安全控制闭环。它用于在演示、验收和日常排障时提供产品使用指南、常见问题和反馈邮箱。

### 6.8.2 当前版本具体功能

当前交付三类静态内容：

1. 使用指南
2. 常见问题
3. 联系与反馈

具体动作包括：

- 从顶部菜单进入帮助与反馈页
- 展开或收起使用指南条目
- 展开或收起常见问题条目
- 查看反馈邮箱

### 6.8.3 关键动作链路

```text
open help-feedback:
  MainPage.setCurrentPage(RouteIds.HELP_FEEDBACK)
  HelpFeedbackPage reads HelpFeedbackStrings
  render guide / FAQ / contact sections

toggle item(index):
  expandedIndex = expandedIndex == index ? -1 : index

back:
  MainPage.setCurrentPage(RouteIds.DASHBOARD)
```

### 6.8.4 成功标准

- 顶部菜单可进入页面
- 使用指南、FAQ 和反馈邮箱完整可见
- 展开/收起只影响当前页面局部状态
- 不申请系统权限，不写本地存储，不依赖企业管理员激活

### 6.8.5 当前不做

- 不提交在线工单
- 不拉起邮件客户端
- 不引入后台反馈服务、Repository 或存储表

## 7. 商业验收口径

### 7.1 功能验收

客户验收时至少应看到：

1. 首页可进入且状态可读
2. 防火墙可切换并能编辑规则
3. 外设可控制并可看到设备连接记录
4. 权限管理可进入并展示首版只读骨架
5. 身份策略可读取和保存
6. 日志可查询和导出
7. 工具设置可启用启动认证
8. 帮助与反馈可进入并展示使用说明、FAQ 和反馈邮箱

### 7.2 演示验收

建议形成以下固定演示动作：

1. 从首页进入
2. 演示防火墙总开关与模式切换
3. 演示外设控制与连接记录
4. 演示权限管理入口和首版范围
5. 演示身份鉴别策略编辑
6. 演示日志筛选与导出
7. 演示启动认证设置
8. 演示帮助与反馈辅助入口

### 7.3 工程验收

研发侧必须满足：

- `MainPage` 为统一入口
- 模块页面可以独立进入和返回
- 关键动作有明确成功/失败反馈
- 状态刷新后不出现明显错乱

## 8. 版本优先级

### 8.1 P0 必须稳定

- 首页摘要与路由
- 防火墙主流程
- 外设主流程
- 日志主流程
- 身份鉴别保存流程
- 工具设置保存流程

### 8.2 P1 持续增强

- 日志稳定性和导出体验
- 外设运行时记录与策略细节
- 防火墙用户级模式下发体验
- 首页摘要准确性

### 8.3 P2 后续扩展

- 更复杂的报表能力
- 更丰富的设备类型
- 更复杂的策略模板和批量能力

## 9. 文档使用规则

1. 产品讨论范围先看 `PRD.md`。
2. 讨论“这个商业版本每个模块到底交什么”先看本文。
3. 讨论“某个模块内部怎么设计、怎么演进或分步推进”看 `docs/03-模块设计/`。
4. 不再保留独立过程文档目录；模块专项推进内容应进入对应模块设计文档。

## 10. 结论

当前版本不是概念验证，而是一个面向商业项目交付的本地安全管理工具。总体设计的重点不是描述抽象架构，而是确保七个核心模块和一个辅助页各自有明确交付内容、可演示动作、可验收标准和清晰边界。后续所有模块变更，都应回到这四个问题：

1. 客户能看到什么
2. 用户能操作什么
3. 结果如何回显
4. 当前版本明确不做什么
