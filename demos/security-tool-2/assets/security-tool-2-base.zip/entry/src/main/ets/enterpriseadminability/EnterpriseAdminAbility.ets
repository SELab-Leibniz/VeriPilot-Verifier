import { adminManager, applicationManager, EnterpriseAdminExtensionAbility } from '@kit.MDMKit'
import type { Want } from '@kit.AbilityKit'
import { commonEventManager } from '@kit.BasicServicesKit'
import osAccount from '@ohos.account.osAccount'
import { ADMIN_WANT, ENTRY_WANT } from '../constants/AppConstants'
import { CommonErrorUtils } from '../utils/CommonErrorUtils'
import { LogUtils } from '../utils/LogUtils'
import { ErrorLike } from '../types/LooseValueTypes'
import {
  ACCOUNT_EVENT_COMMON_EVENT,
  ACCOUNT_EVENT_PARAM_TIMESTAMP,
  ACCOUNT_EVENT_PARAM_TYPE,
  ACCOUNT_EVENT_PARAM_USER_ID,
  AccountEventType
} from '../contracts/AccountEventContract'


const TAG = 'EnterpriseAdminAbility'

export default class EnterpriseAdminAbility extends EnterpriseAdminExtensionAbility {
  onStart(): void {
    this.ensureAutoStartAppRegistered('onStart')
  }

  onAdminEnabled(): void {
    LogUtils.info(TAG, 'Enterprise admin enabled')
    this.ensureAutoStartAppRegistered('onAdminEnabled')
    this.ensureKeepAliveAppsForCurrentAccounts('onAdminEnabled')
    this.subscribeAccountManagedEvents()
  }

  onAdminDisabled(): void {
    LogUtils.info(TAG, 'Enterprise admin disabled')
    this.unsubscribeAccountManagedEvents()
  }

  onBundleAdded(bundleName: string): void {
    LogUtils.info(TAG, `Bundle added: ${bundleName}`)
  }

  onBundleRemoved(bundleName: string): void {
    LogUtils.info(TAG, `Bundle removed: ${bundleName}`)
  }

  onAccountAdded(accountId: number): void {
    LogUtils.info(TAG, 'Account added: %{public}d', accountId)
    this.publishAccountEvent(AccountEventType.ADDED, accountId)
    this.ensureKeepAliveAppRegistered('onAccountAdded', accountId)
  }

  onAccountRemoved(accountId: number): void {
    LogUtils.info(TAG, 'Account removed: %{public}d', accountId)
    this.removeKeepAliveAppRegistration('onAccountRemoved', accountId)
    this.publishAccountEvent(AccountEventType.REMOVED, accountId)
  }

  private publishAccountEvent(type: AccountEventType, userId: number): void {
    if (!Number.isFinite(userId) || userId < 0) {
      LogUtils.warn(TAG, 'publishAccountEvent skipped invalid userId=%{public}s, type=%{public}s', String(userId), type)
      return
    }
    let timestamp = Date.now()
    let parameters: Record<string, Object> = {}
    parameters[ACCOUNT_EVENT_PARAM_TYPE] = type
    parameters[ACCOUNT_EVENT_PARAM_USER_ID] = userId
    parameters[ACCOUNT_EVENT_PARAM_TIMESTAMP] = timestamp

    let publishData: commonEventManager.CommonEventPublishData = {
      data: JSON.stringify(parameters),
      parameters: parameters
    }
    commonEventManager.publish(ACCOUNT_EVENT_COMMON_EVENT, publishData, (err) => {
      if (err) {
        LogUtils.warn(TAG, 'publishAccountEvent failed: type=%{public}s, userId=%{public}d, err=%{public}s',
          type, userId, JSON.stringify(err))
        return
      }
      LogUtils.info(TAG, 'publishAccountEvent success: type=%{public}s, userId=%{public}d', type, userId)
    })
  }

  private subscribeAccountManagedEvents(): void {
    try {
      let events: Array<adminManager.ManagedEvent> = [
        adminManager.ManagedEvent.MANAGED_EVENT_ACCOUNT_ADDED,
        adminManager.ManagedEvent.MANAGED_EVENT_ACCOUNT_REMOVED
      ]
      adminManager.subscribeManagedEventSync(ADMIN_WANT, events)
      LogUtils.info(TAG, 'subscribeAccountManagedEvents success: count=%{public}d', events.length)
    } catch (err) {
      LogUtils.error(TAG, `subscribeAccountManagedEvents failed: ${JSON.stringify(err)}`)
    }
  }

  private unsubscribeAccountManagedEvents(): void {
    try {
      let events: Array<adminManager.ManagedEvent> = [
        adminManager.ManagedEvent.MANAGED_EVENT_ACCOUNT_ADDED,
        adminManager.ManagedEvent.MANAGED_EVENT_ACCOUNT_REMOVED
      ]
      adminManager.unsubscribeManagedEventSync(ADMIN_WANT, events)
      LogUtils.info(TAG, 'unsubscribeAccountManagedEvents success: count=%{public}d', events.length)
    } catch (err) {
      LogUtils.warn(TAG, `unsubscribeAccountManagedEvents failed: ${JSON.stringify(err)}`)
    }
  }

  private ensureAutoStartAppRegistered(source: string): void {
    try {
      let currentApps: Array<Want> = applicationManager.getAutoStartApps(ADMIN_WANT)
      let alreadyRegistered = currentApps.some((item: Want) =>
        item.bundleName === ENTRY_WANT.bundleName && item.abilityName === ENTRY_WANT.abilityName
      )
      if (alreadyRegistered) {
        LogUtils.info(TAG, 'ensureAutoStartAppRegistered skipped | source=%{public}s, alreadyRegistered=true', source)
        return
      }
      applicationManager.addAutoStartApps(ADMIN_WANT, [ENTRY_WANT])
      LogUtils.info(TAG, 'ensureAutoStartAppRegistered success | source=%{public}s, bundle=%{public}s, ability=%{public}s',
        source, ENTRY_WANT.bundleName ?? '-', ENTRY_WANT.abilityName ?? '-')
    } catch (err) {
      let error: ErrorLike = err as ErrorLike
      let code = CommonErrorUtils.extractErrorCode(error)
      LogUtils.warn(TAG, 'ensureAutoStartAppRegistered failed | source=%{public}s, code=%{public}s, err=%{public}s',
        source, `${code ?? 'unknown'}`, JSON.stringify(err))
    }
  }

  private async ensureKeepAliveAppsForCurrentAccounts(source: string): Promise<void> {
    try {
      let accountIds = await osAccount.getAccountManager().getActivatedOsAccountLocalIds()
      if (accountIds.length === 0) {
        LogUtils.warn(TAG, 'ensureKeepAliveAppsForCurrentAccounts skipped | source=%{public}s, accountCount=0', source)
        return
      }
      for (let accountId of accountIds) {
        this.ensureKeepAliveAppRegistered(source, accountId)
      }
    } catch (err) {
      let error: ErrorLike = err as ErrorLike
      let code = CommonErrorUtils.extractErrorCode(error)
      LogUtils.warn(TAG, 'ensureKeepAliveAppsForCurrentAccounts failed | source=%{public}s, code=%{public}s, err=%{public}s',
        source, `${code ?? 'unknown'}`, JSON.stringify(err))
    }
  }

  private ensureKeepAliveAppRegistered(source: string, accountId: number): void {
    this.reconcileKeepAliveAppRegistration(source, accountId, true)
  }

  private removeKeepAliveAppRegistration(source: string, accountId: number): void {
    this.reconcileKeepAliveAppRegistration(source, accountId, false)
  }

  private reconcileKeepAliveAppRegistration(source: string, accountId: number, shouldRegister: boolean): void {
    let bundleName = ENTRY_WANT.bundleName
    if (!bundleName) {
      LogUtils.warn(TAG,
        'reconcileKeepAliveAppRegistration skipped | source=%{public}s, accountId=%{public}d, bundleName=empty',
        source, accountId)
      return
    }
    try {
      let currentBundles = applicationManager.getKeepAliveApps(ADMIN_WANT, accountId)
      let alreadyRegistered = currentBundles.includes(bundleName)
      if (alreadyRegistered === shouldRegister) {
        LogUtils.info(TAG,
          'reconcileKeepAliveAppRegistration skipped | source=%{public}s, accountId=%{public}d, targetRegistered=%{public}s',
          source, accountId, String(shouldRegister))
        return
      }
      if (shouldRegister) {
        applicationManager.addKeepAliveApps(ADMIN_WANT, [bundleName], accountId)
      } else {
        applicationManager.removeKeepAliveApps(ADMIN_WANT, [bundleName], accountId)
      }
      LogUtils.info(TAG,
        'reconcileKeepAliveAppRegistration success | source=%{public}s, accountId=%{public}d, targetRegistered=%{public}s, bundle=%{public}s',
        source, accountId, String(shouldRegister), bundleName)
    } catch (err) {
      let error: ErrorLike = err as ErrorLike
      let code = CommonErrorUtils.extractErrorCode(error)
      LogUtils.warn(TAG,
        'reconcileKeepAliveAppRegistration failed | source=%{public}s, accountId=%{public}d, targetRegistered=%{public}s, code=%{public}s, err=%{public}s',
        source, accountId, String(shouldRegister), `${code ?? 'unknown'}`, JSON.stringify(err))
    }
  }
}
