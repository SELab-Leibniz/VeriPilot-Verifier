import { LogUtils } from '../../../utils/LogUtils'
import { AppColors, AppStyles } from '../../../constants/AppConstants'
import { AppResources } from '../../../constants/AppResources'
import { ModuleText, StatusText } from '../../../constants/StringCatalog'
import { LoadingStrings } from '../../../constants/modules/DialogStrings'
import {
  FirewallPageStrings,
  FirewallToggleStrings,
  buildFirewallToggleFailedMessage,
  getFirewallModeAccent,
  getFirewallModeDescription,
  getFirewallModeTitle
} from '../../../constants/modules/FirewallStrings'
import { SubPageHeader } from '../../../components/SubPageHeader'

import { common } from '@kit.AbilityKit'
import { FirewallPresetMode, FirewallToggleRejectReason } from '../../../services/firewall/FirewallModels'
import { FirewallOverviewViewModel } from '../../../viewmodels/firewall/overview/FirewallOverviewViewModel'
import { ThemeMode } from '../../../theme/ThemeColors'
import { HoverUtils } from '../../../utils/HoverUtils'
import { getScrollBarColor, SCROLL_BAR_WIDTH_DEFAULT, SCROLL_BAR_WIDTH_HOVER } from '../../../utils/ScrollBarStyleUtils'
import { DialogService } from '../../../utils/DialogService'
import { TimedLoadingDialogRunner } from '../../../utils/TimedLoadingDialogRunner'

const TAG = 'FirewallPage'

@ComponentV2
export struct FirewallPage {
  @Param overviewViewModel: FirewallOverviewViewModel = new FirewallOverviewViewModel()
  @Param currentTheme: ThemeMode = ThemeMode.LIGHT
  @Local isToggleProcessing: boolean = false
  @Local isModeProcessing: boolean = false
  @Local hoveredMode: string = ''
  @Event onNavigateToRules: () => void = () => {}
  @Event onBack: () => void = () => {}
  private readonly modeLoadingRunner: TimedLoadingDialogRunner = new TimedLoadingDialogRunner(TAG)
  @Local private scrollBarWidth: number = SCROLL_BAR_WIDTH_DEFAULT

  aboutToAppear() {
    LogUtils.info(
      TAG,
      `page enter: firewallEnabled=${this.overviewViewModel.state.enabled}, currentMode=${this.overviewViewModel.state.currentMode}`
    )
  }

  aboutToDisappear() {
    this.modeLoadingRunner.closeIfOpen('page-disappear')
    LogUtils.info(
      TAG,
      `page exit: firewallEnabled=${this.overviewViewModel.state.enabled}, currentMode=${this.overviewViewModel.state.currentMode}`
    )
  }

  async handleToggleWithAuth(isOn: boolean) {
    if (this.isToggleProcessing || this.isModeSwitching()) {
      return
    }
    let currentEnabled = this.overviewViewModel.state.enabled
    if (isOn === currentEnabled) {
      return
    }

    this.isToggleProcessing = true
    try {
      let context: common.UIAbilityContext = this.getUIContext().getHostContext() as common.UIAbilityContext
      let result = await this.overviewViewModel.requestToggle(context, isOn)
      if (result.success) {
        return
      }

      DialogService.openFailure(
        this.getUIContext(),
        result.errorMessage ?? this.buildToggleFailedMessage(result.reason, result.lockRemainingSec)
      )
    } catch (err) {
      DialogService.openFailure(this.getUIContext(), FirewallToggleStrings.TOGGLE_FAILED)
      LogUtils.error(TAG, `handleToggleWithAuth failed: ${JSON.stringify(err)}`)
    } finally {
      this.isToggleProcessing = false
    }
  }

  private buildToggleFailedMessage(
    reason: FirewallToggleRejectReason | undefined,
    lockRemainingSec: number | undefined
  ): string {
    return buildFirewallToggleFailedMessage(reason, lockRemainingSec)
  }

  private getModeTitle(mode: FirewallPresetMode): string {
    return getFirewallModeTitle(mode)
  }

  private getModeDescription(mode: FirewallPresetMode): string {
    return getFirewallModeDescription(mode)
  }

  private getModeIcon(mode: FirewallPresetMode): Resource {
    switch (mode) {
      case 'public':
        return AppResources.GLOBE_ICON
      case 'private':
        return AppResources.SHIELD_ICON
      case 'custom':
      default:
        return AppResources.FIREWALL_ICON
    }
  }

  private getModeAccent(mode: FirewallPresetMode): string {
    return getFirewallModeAccent(mode)
  }

  private getThemeColors() {
    return AppColors.getColors(this.currentTheme)
  }

  private isModeSelected(mode: FirewallPresetMode): boolean {
    return this.overviewViewModel.state.currentMode === mode
  }

  private isModeHovered(mode: FirewallPresetMode): boolean {
    return this.canOperateModeCards() && this.hoveredMode === mode
  }

  private isToggleSwitching(): boolean {
    return this.isToggleProcessing || this.overviewViewModel.state.isToggleProcessing
  }

  private isModeSwitching(): boolean {
    return this.isModeProcessing || this.overviewViewModel.state.isModeProcessing
  }

  private canOperateModeCards(): boolean {
    return this.overviewViewModel.state.enabled && !this.isToggleSwitching() && !this.isModeSwitching()
  }

  private getModeCardBackground(mode: FirewallPresetMode): string {
    if (this.isModeSelected(mode)) {
      return this.currentTheme === ThemeMode.DARK ? AppColors.FIREWALL_SELECTED_CARD_BG_DARK : AppColors.FIREWALL_SELECTED_CARD_BG_LIGHT
    }
    return this.getThemeColors().BG_CARD
  }

  private getModeCardBorder(mode: FirewallPresetMode): string {
    return this.isModeSelected(mode) ? this.getModeAccent(mode) : this.getThemeColors().BORDER
  }

  private getModeCardBorderWidth(mode: FirewallPresetMode): number {
    return this.isModeSelected(mode) ? 2 : AppStyles.DIVIDER_HEIGHT
  }

  private getModeIconContainerBorder(mode: FirewallPresetMode): BorderOptions {
    if (!this.isModeSelected(mode)) {
      return {
        width: 0
      }
    }
    return {
      width: 3,
      color: this.currentTheme === ThemeMode.DARK ? AppColors.FIREWALL_SELECTED_ICON_BORDER_DARK : AppColors.FIREWALL_SELECTED_ICON_BORDER_LIGHT
    }
  }

  private getModeIconContainerShadow(mode: FirewallPresetMode): ShadowOptions | ShadowStyle {
    if (!this.isModeSelected(mode)) {
      return ShadowStyle.OUTER_DEFAULT_SM
    }
    return {
      radius: 16,
      color: this.currentTheme === ThemeMode.DARK ? AppColors.FIREWALL_SELECTED_SHADOW_DARK : AppColors.FIREWALL_SELECTED_SHADOW_LIGHT,
      offsetX: 0,
      offsetY: 6
    }
  }

  private getModeTitleColor(mode: FirewallPresetMode): string {
    return this.isModeSelected(mode) ? this.getModeAccent(mode) : this.getThemeColors().TEXT_PRIMARY
  }

  private getModeTitleOpacity(mode: FirewallPresetMode): number {
    return this.isModeSelected(mode) ? 1 : this.getThemeColors().TEXT_PRIMARY_OPACITY
  }

  private getModeDescriptionOpacity(mode: FirewallPresetMode): number {
    return this.isModeSelected(mode) ? this.getThemeColors().TEXT_SECONDARY_OPACITY : this.getThemeColors().TEXT_TERTIARY_OPACITY
  }

  private getModeStatusBackground(mode: FirewallPresetMode): string {
    return this.currentTheme === ThemeMode.DARK ? `${this.getModeAccent(mode)}33` : this.getModeAccent(mode)
  }

  private getModeStatusTextColor(mode: FirewallPresetMode): string {
    return this.currentTheme === ThemeMode.DARK ? this.getModeAccent(mode) : AppColors.FIREWALL_SELECTED_ICON_BORDER_LIGHT
  }

  private getModeStatusBorder(mode: FirewallPresetMode): BorderOptions {
    if (this.currentTheme === ThemeMode.DARK) {
      return {
        width: AppStyles.DIVIDER_HEIGHT,
        color: `${this.getModeAccent(mode)}55`
      }
    }
    return {
      width: 0
    }
  }

  private getModeCardShadow(mode: FirewallPresetMode): ShadowOptions {
    return HoverUtils.getShadow(this.currentTheme, this.isModeHovered(mode), true)
  }

  private getModeCardTranslateY(mode: FirewallPresetMode): number {
    return HoverUtils.getTranslateY(this.isModeHovered(mode), 4)
  }

  private getModeCardScale(mode: FirewallPresetMode): number {
    return HoverUtils.getScale(this.isModeHovered(mode))
  }

  private showModeChangeFailedDialog(): void {
    DialogService.openFailure(this.getUIContext(), FirewallToggleStrings.MODE_APPLY_FAILED)
  }

  private async handleModeSelect(mode: FirewallPresetMode): Promise<void> {
    if (!this.canOperateModeCards()) {
      return
    }
    if (this.isModeProcessing) {
      return
    }
    if (mode === this.overviewViewModel.state.currentMode) {
      if (mode === 'custom') {
        this.onNavigateToRules()
      }
      return
    }
    this.isModeProcessing = true
    let success = false
    try {
      LogUtils.info(TAG, `mode switch start: current=${this.overviewViewModel.state.currentMode}, target=${mode}`)
      success = await this.modeLoadingRunner.run(
        'firewall-mode-switch',
        LoadingStrings.APPLYING_MODE,
        async (): Promise<boolean> => {
          let context: common.UIAbilityContext = this.getUIContext().getHostContext() as common.UIAbilityContext
          let result = await this.overviewViewModel.requestModeSwitch(context, mode)
          return result.success
        },
        (dialogMessage: string): CustomDialogController => DialogService.createLoadingController(dialogMessage, this.currentTheme)
      )
    } catch (err) {
      LogUtils.error(TAG, `handleModeSelect failed: ${JSON.stringify(err)}`)
    } finally {
      this.isModeProcessing = false
    }
    if (!success) {
      this.showModeChangeFailedDialog()
      return
    }
    LogUtils.info(TAG, `mode switch success: target=${mode}`)
    if (mode === 'custom') {
      this.onNavigateToRules()
    }
  }

  @Builder
  private modeCard(mode: FirewallPresetMode) {
    Row({ space: 16 }) {
      Row() {
        Image(this.getModeIcon(mode))
          .width(22)
          .height(22)
          .fillColor(Color.White)
          .draggable(false)
      }
      .width(AppStyles.ICON_TILE_SIZE_LG)
      .height(AppStyles.ICON_TILE_SIZE_LG)
      .borderRadius(24)
      .justifyContent(FlexAlign.Center)
      .alignItems(VerticalAlign.Center)
      .backgroundColor(this.getModeAccent(mode))
      .border(this.getModeIconContainerBorder(mode))
      .shadow(this.getModeIconContainerShadow(mode))
      .scale({
        x: HoverUtils.getScale(this.isModeHovered(mode), 1.04),
        y: HoverUtils.getScale(this.isModeHovered(mode), 1.04)
      })

      Column({ space: 6 }) {
        if (this.isModeSelected(mode)) {
          Row({ space: 4 }) {
            Image(AppResources.CHECK_ICON)
              .width(12)
              .height(12)
              .fillColor(this.getModeStatusTextColor(mode))
            Text(StatusText.CURRENT_MODE)
              .fontSize(AppStyles.FONT_SIZE_MICRO)
              .fontWeight(FontWeight.Medium)
              .fontColor(this.getModeStatusTextColor(mode))
          }
          .padding({ left: 8, right: 8, top: 4, bottom: 4 })
          .borderRadius(AppStyles.RADIUS_PILL)
          .backgroundColor(this.getModeStatusBackground(mode))
          .border(this.getModeStatusBorder(mode))
        }

        Text(this.getModeTitle(mode))
          .fontSize(AppStyles.FONT_SIZE_BODY)
          .fontWeight(this.isModeSelected(mode) ? FontWeight.Bold : FontWeight.Medium)
          .fontColor(this.getModeTitleColor(mode))
          .opacity(this.getModeTitleOpacity(mode))

        Text(this.getModeDescription(mode))
          .fontSize(AppStyles.FONT_SIZE_CAPTION)
          .fontColor(this.getThemeColors().TEXT_PRIMARY)
          .opacity(this.getModeDescriptionOpacity(mode))
          .maxLines(2)
          .textOverflow({ overflow: TextOverflow.Ellipsis })
      }
      .alignItems(HorizontalAlign.Start)
      .layoutWeight(1)

      Column({ space: 8 }) {
        if (mode === 'custom') {
          Row({ space: 4 }) {
            Text(FirewallPageStrings.RULES_PAGE)
              .fontSize(AppStyles.FONT_SIZE_MICRO)
              .fontWeight(FontWeight.Medium)
              .fontColor(this.getThemeColors().TEXT_PRIMARY)
              .opacity(this.isModeSelected(mode) ? this.getThemeColors().TEXT_SECONDARY_OPACITY : this.getThemeColors().TEXT_TERTIARY_OPACITY)
            Image(AppResources.CHEVRON_RIGHT_ICON)
              .width(16)
              .height(16)
              .fillColor(this.getThemeColors().TEXT_PRIMARY)
              .opacity(this.isModeSelected(mode) ? this.getThemeColors().TEXT_SECONDARY_OPACITY : this.getThemeColors().TEXT_TERTIARY_OPACITY)
          }
        } else if (this.isModeSelected(mode)) {
          Row({ space: 4 }) {
            Text(StatusText.EFFECTIVE)
              .fontSize(AppStyles.FONT_SIZE_MICRO)
              .fontWeight(FontWeight.Medium)
              .fontColor(this.getThemeColors().TEXT_PRIMARY)
              .opacity(this.getThemeColors().TEXT_SECONDARY_OPACITY)
            Image(AppResources.CHECK_ICON)
              .width(14)
              .height(14)
              .fillColor(this.getModeAccent(mode))
          }
        } else {
          Image(AppResources.CHECK_ICON)
            .width(14)
            .height(14)
            .fillColor(this.getThemeColors().TEXT_PRIMARY)
            .opacity(0)
        }
      }
      .alignItems(HorizontalAlign.End)
      .justifyContent(FlexAlign.Center)
    }
    .alignItems(VerticalAlign.Center)
    .width('100%')
    .padding(18)
    .backgroundColor(this.getModeCardBackground(mode))
    .borderRadius(AppStyles.RADIUS_LG)
    .border({
      width: this.getModeCardBorderWidth(mode),
      color: this.getModeCardBorder(mode)
    })
    .shadow(this.getModeCardShadow(mode))
    .translate({ y: this.getModeCardTranslateY(mode) })
    .scale({
      x: this.getModeCardScale(mode),
      y: this.getModeCardScale(mode)
    })
    .opacity(this.canOperateModeCards() ? (this.isModeProcessing ? 0.75 : 1) : 0.56)
    .onHover((isHover: boolean) => {
      if (!this.canOperateModeCards()) {
        if (this.hoveredMode === mode) {
          this.hoveredMode = ''
        }
        return
      }
      HoverUtils.animate(this.getUIContext(), () => {
        if (isHover) {
          this.hoveredMode = mode
        } else if (this.hoveredMode === mode) {
          this.hoveredMode = ''
        }
      })
    })
    .onClick(() => {
      if (this.canOperateModeCards()) {
        this.handleModeSelect(mode)
      }
    })
  }

  build() {
    Column() {
      SubPageHeader({
          title: ModuleText.FIREWALL,
        subtitle: FirewallPageStrings.SUBTITLE,
        currentTheme: this.currentTheme,
        onBack: () => this.onBack(),
        actions: () => {
          this.headerActions()
        }
      })

      Scroll() {
        Column({ space: 24 }) {
          Column({ space: 12 }) {
            this.modeCard('public')
            this.modeCard('private')
            this.modeCard('custom')
          }
          .width('100%')
        }
        .padding({
          left: AppStyles.PADDING_LG,
          right: AppStyles.PADDING_LG,
          top: AppStyles.PADDING_MD,
          bottom: AppStyles.PADDING_LG
        })
        .width('100%')
      }
      .width('100%')
      .layoutWeight(1)
      .scrollBar(BarState.Auto)
      .scrollBarColor(getScrollBarColor(this.currentTheme))
      .scrollBarWidth(this.scrollBarWidth)
      .onHover((isHover: boolean) => {
        this.scrollBarWidth = isHover ? SCROLL_BAR_WIDTH_HOVER : SCROLL_BAR_WIDTH_DEFAULT
      })
      .align(Alignment.Top)
    }
    .width('100%')
    .height('100%')
    .backgroundColor(this.getThemeColors().BG_PAGE)
  }

  @Builder
  private headerActions() {
    Toggle({ type: ToggleType.Switch, isOn: this.overviewViewModel.state.enabled })
      .selectedColor(AppColors.BRAND_PRIMARY)
      .switchPointColor(Color.White)
      .enabled(!this.isToggleSwitching() && !this.isModeSwitching())
      .onChange((isOn: boolean) => {
        this.handleToggleWithAuth(isOn)
      })
  }
}
