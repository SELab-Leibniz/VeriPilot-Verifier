import { afterEach, beforeEach, describe, expect, it } from '@ohos/hypium'
import { usbManager as edmUsbManager } from '@kit.MDMKit'
import { ArgumentMatchers, MockKit, when } from '@ohos/hamock'
import { OperationResult } from '../../main/ets/models/CommonModels'
import { PeripheralReasonCodes } from '../../main/ets/constants/modules/PeripheralStrings'
import { PeripheralService } from '../../main/ets/services/peripheral/interface-control/PeripheralService'
import { InterfaceControlViewModel } from '../../main/ets/viewmodels/peripheral/interface-control/InterfaceControlViewModel'
import { PeripheralDevicePolicyRepository } from '../../main/ets/services/peripheral/device-policy/PeripheralDevicePolicyRepository'

class VoidOperationResult implements OperationResult<void> {
  success: boolean = false
  stage?: string
}

class BooleanOperationResult implements OperationResult<boolean> {
  success: boolean = false
  stage?: string
  data?: boolean
}

class UsbPolicyOperationResult implements OperationResult<edmUsbManager.UsbPolicy> {
  success: boolean = false
  stage?: string
  data?: edmUsbManager.UsbPolicy
}

export default function interfaceControlViewModelTest() {
  describe('InterfaceControlViewModel', () => {
    let viewModel: InterfaceControlViewModel
    let mockKit: MockKit

  beforeEach(() => {
    viewModel = new InterfaceControlViewModel()
    mockKit = new MockKit()
  })

  afterEach(() => {
    mockKit.clearAll()
  })

  it('should toggle interface successfully', 0, async (done: Function) => {
    let setUsbDefaultPolicyMock = mockKit.mockFunc(
      PeripheralDevicePolicyRepository,
      PeripheralDevicePolicyRepository.setUsbDefaultPolicy
    )
    when(setUsbDefaultPolicyMock)('deny').afterReturn(Promise.resolve(true))

    const reason = await viewModel.toggleInterface(PeripheralService.FEATURE_USB, true)

    expect(reason).assertNull()
    expect(viewModel.processingKey).assertEqual('')
    expect(viewModel.state.usbDisabled).assertTrue()
    done()
  })

  it('should surface failure stage for interface toggle', 0, async (done: Function) => {
    let setUsbDefaultPolicyMock = mockKit.mockFunc(
      PeripheralDevicePolicyRepository,
      PeripheralDevicePolicyRepository.setUsbDefaultPolicy
    )
    when(setUsbDefaultPolicyMock)('deny').afterReturn(Promise.resolve(false))

    const reason = await viewModel.toggleInterface(PeripheralService.FEATURE_USB, true)

    expect(reason).assertEqual(PeripheralReasonCodes.TOGGLE_INTERFACE_FAILED)
    done()
  })

  it('should reload usb interface state from local default policy', 0, async (done: Function) => {
    let isUsbDefaultDenyMock = mockKit.mockFunc(
      PeripheralDevicePolicyRepository,
      PeripheralDevicePolicyRepository.isUsbDefaultDeny
    )
    let getInterfaceMock = mockKit.mockFunc(PeripheralService, PeripheralService.getInterfaceDisabledWithResult)
    let getUsbStorageMock = mockKit.mockFunc(PeripheralService, PeripheralService.getUsbStoragePolicyWithResult)
    let restorePowerMock = mockKit.mockFunc(PeripheralService, PeripheralService.restoreEnabledInterfacePowerWithResult)
    let getInterfaceResult = new BooleanOperationResult()
    getInterfaceResult.success = true
    getInterfaceResult.data = false
    let usbResult = new UsbPolicyOperationResult()
    usbResult.success = true
    usbResult.data = edmUsbManager.UsbPolicy.READ_WRITE
    let restoreResult = new VoidOperationResult()
    restoreResult.success = true
    when(isUsbDefaultDenyMock)().afterReturn(true)
    when(getInterfaceMock)(ArgumentMatchers.any).afterReturn(getInterfaceResult)
    when(getUsbStorageMock)().afterReturn(usbResult)
    when(restorePowerMock)(ArgumentMatchers.any).afterReturn(restoreResult)

    viewModel.reloadState()

    expect(viewModel.state.usbDisabled).assertTrue()
    done()
  })

  it('should update usb storage policy successfully', 0, async (done: Function) => {
    let setUsbStorageMock = mockKit.mockFunc(PeripheralService, PeripheralService.setUsbStoragePolicyWithCleanupResult)
    let getInterfaceMock = mockKit.mockFunc(PeripheralService, PeripheralService.getInterfaceDisabledWithResult)
    let getUsbStorageMock = mockKit.mockFunc(PeripheralService, PeripheralService.getUsbStoragePolicyWithResult)
    let setResult = new VoidOperationResult()
    setResult.success = true
    let getInterfaceResult = new BooleanOperationResult()
    getInterfaceResult.success = true
    getInterfaceResult.data = false
    let usbResult = new UsbPolicyOperationResult()
    usbResult.success = true
    usbResult.data = edmUsbManager.UsbPolicy.DISABLED
    when(setUsbStorageMock)(edmUsbManager.UsbPolicy.DISABLED).afterReturn(setResult)
    when(getInterfaceMock)(PeripheralService.FEATURE_USB).afterReturn(getInterfaceResult)
    when(getUsbStorageMock)().afterReturn(usbResult)

    const reason = await viewModel.setUsbStoragePolicy(2)

    expect(reason).assertNull()
    expect(viewModel.state.usbStoragePolicyIndex).assertEqual(2)
    done()
  })

  it('should surface failure stage for usb storage policy change', 0, async (done: Function) => {
    let setUsbStorageMock = mockKit.mockFunc(PeripheralService, PeripheralService.setUsbStoragePolicyWithCleanupResult)
    let setResult = new VoidOperationResult()
    setResult.success = false
    setResult.stage = 'set_usb_storage_policy'
    when(setUsbStorageMock)(edmUsbManager.UsbPolicy.READ_ONLY).afterReturn(setResult)

    const reason = await viewModel.setUsbStoragePolicy(0)

    expect(reason).assertEqual('set_usb_storage_policy')
    done()
  })

  it('should surface system conflict reason for usb storage policy change', 0, async (done: Function) => {
    let setUsbStorageMock = mockKit.mockFunc(PeripheralService, PeripheralService.setUsbStoragePolicyWithCleanupResult)
    let setResult = new VoidOperationResult()
    setResult.success = false
    setResult.stage = PeripheralReasonCodes.SET_USB_STORAGE_POLICY_CONFLICT
    when(setUsbStorageMock)(edmUsbManager.UsbPolicy.READ_ONLY).afterReturn(setResult)

    const reason = await viewModel.setUsbStoragePolicy(0)

    expect(reason).assertEqual(PeripheralReasonCodes.SET_USB_STORAGE_POLICY_CONFLICT)
    done()
  })

  it('should toggle bluetooth interface successfully', 0, async (done: Function) => {
    let setInterfaceMock = mockKit.mockFunc(PeripheralService, PeripheralService.setInterfaceDisabledWithResult)
    let setResult = new VoidOperationResult()
    setResult.success = true
    when(setInterfaceMock)(ArgumentMatchers.any).afterReturn(setResult)

    const reason = await viewModel.toggleInterface(PeripheralService.FEATURE_BLUETOOTH, true)

    expect(reason).assertNull()
    expect(viewModel.state.btDisabled).assertTrue()
    done()
  })

  it('should toggle wifi interface successfully', 0, async (done: Function) => {
    let setInterfaceMock = mockKit.mockFunc(PeripheralService, PeripheralService.setInterfaceDisabledWithResult)
    let setResult = new VoidOperationResult()
    setResult.success = true
    when(setInterfaceMock)(ArgumentMatchers.any).afterReturn(setResult)

    const reason = await viewModel.toggleInterface(PeripheralService.FEATURE_WIFI, true)

    expect(reason).assertNull()
    expect(viewModel.state.wifiDisabled).assertTrue()
    done()
  })

  it('should surface wifi power restore failure when enabling interface', 0, async (done: Function) => {
    viewModel.state.wifiDisabled = true
    let setInterfaceMock = mockKit.mockFunc(PeripheralService, PeripheralService.setInterfaceDisabledWithResult)
    let setResult = new VoidOperationResult()
    setResult.success = false
    setResult.stage = PeripheralReasonCodes.TURN_ON_WIFI_FAILED
    when(setInterfaceMock)(ArgumentMatchers.any).afterReturn(setResult)

    const reason = await viewModel.toggleInterface(PeripheralService.FEATURE_WIFI, false)

    expect(reason).assertEqual(PeripheralReasonCodes.TOGGLE_INTERFACE_FAILED)
    expect(viewModel.state.wifiDisabled).assertTrue()
    done()
  })
  })
}
